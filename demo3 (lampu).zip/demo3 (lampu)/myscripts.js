function turnOn() {
    document.getElementById('myImage').src = 'pic_on.jpg';
}

function turnOff() {
    document.getElementById('myImage').src = 'pic_off.jpg';
}