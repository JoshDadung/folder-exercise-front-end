export default function message() {
    return `
      <div style="border: 1px solid black; padding: 15px; width: 50%; margin: 0 auto;">
        <h2 style="text-align: center; font-weight: bold;">Personal Information</h2>
        <hr>
        <ul style="list-style-type: none; padding-left: 0;">
          <li><strong>Name:</strong> Dadung,Joshua Clyford </li>
          <li><strong>Age:</strong> 20 years old</li>
          <li><strong>Status:</strong> Single</li>
          <li><strong>Major:</strong> Information Systems</li>
          <li><strong>Faculty:</strong> Computer Science</li>
          <li><strong>Address:</strong> Asrama Crystal</li>
          <li><strong>Interests:</strong> Design </li>
        </ul>
      </div>
    `;
}