// create variable header
let header = (
    <header className="header">
        <h1> buat header Menggunakan JSX</h1>
        <p>tutorial JSX sederhana</p>
    </header>
)

// render elemen ke dom
ReactDOM.render(header, document.getElementById("app"));