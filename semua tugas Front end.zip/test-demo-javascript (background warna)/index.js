// function for action performs
function myHello() {
    document.getElementById("greetings").innerHTML = "Hello Student, welcome to this class.";
}

function bgRed() {
    document.body.style.background = 'red';
}

function bgBlue() {
    document.body.style.background = 'blue';
}

function bgGreen () {
    document.body.style.background = 'green';
}

function bgYellow() {
    document.body.style.background = 'yellow';
}

function bgWhite() {
    document.body.style.background = 'white';
}